package toby;

public class Controller
{
	public Controller()
	{
		System.out.println("[Controller]: -------------------------------------");
		System.out.println("[Controller]: -                                   -");
		System.out.println("[Controller]: -       Toby the Trading Bot        -");
		System.out.println("[Controller]: -                                   -");
		System.out.println("[Controller]: - Copyright Ethan Witherington 2017 -");
		System.out.println("[Controller]: -                                   -");
		System.out.println("[Controller]: -------------------------------------");
		System.out.println("[Controller]: ");
		System.out.println("[Controller]: Initializing Daemon...");
		Thread thread = new Thread( new Daemon() );
		System.out.println("[Controller]: Daemon Initialized! Starting Thread...");
		thread.start();
		System.out.println("[Controller]: Thread Started and Running! My job is done, Daemon will take it from here.");
	}

	public static void main(String[] args)
	{
		new Controller();
	}
}
