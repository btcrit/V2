package toby;
import toby.strategies.Strategy_Generic;
import toby.minterfaces.MInterface_Generic;

public class Daemon implements Runnable
{
	//Clock
	Clock clock;
	//Strategy
	Strategy_Generic strategy;
	//MarketInterface
	MInterface_Generic minterface;
	public Daemon()
	{
		System.out.println("[Daemon]: Initializing Daemon...");
		System.out.println("[Daemon]: Creating Clock...");
		clock = new Clock();
		System.out.println("[Daemon]: Clock Created! Triggering Settings System...");
		//TODO Tell settings to initialize
		System.out.println("[Daemon]: Settings System up and running! Creating Market Interface...");
		try
			{
				minterface = Settings.MARKET_SYSTEM.newInstance();
			}
			catch (Exception e)
			{
				System.out.println("[Daemon]: Selected Market Interface cannot be created. Check your Market Interface Settings. Printing Error report and Exiting...");
				e.printStackTrace();
				System.exit(1);
			}
		System.out.println("[Daemon]: Market Interface Created! Creating Trading Strategy...");
		try
			{
				strategy = Settings.strategy.getConstructor(MInterface_Generic.class).newInstance(minterface);//newInstance();// I FREAKING LOVE OOP
			}
			catch(Exception e)
			{
				System.out.println("[Daemon]: Selected Trading Strategy could not be created. Check your settings. Printing Error Report and Exiting...");
				e.printStackTrace();
				System.exit(1);
			}
		System.out.println("[Daemon]: Trading Strategy Created!");
		System.out.println("[Daemon]: Daemon Initialized!");
	}

	@Override
	public void run()
	{
		System.out.print("[Daemon]: Starting Trade Loop!");
		//What happens when it's time to run
		while(true)//Always and Forever
		{
			System.out.println(" Gathering Price Data through Market Interface...");
			//Pre-tick the market
			minterface.pretick();//TODO
			System.out.println("[Daemon]: Market Interface has Completed, Activating Trading Strategy...");
			//Run the strategy
			strategy.tick();//TODO
			System.out.println("[Daemon]: Trading Strategy Has Completed, Activating Clock to wait until next analysis.");
			//Wait before doing it all again
			clock.tick();
			System.out.print("[Daemon]: Clock has Completed,");
		}
	}

}
