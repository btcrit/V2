package toby.strategies;
import toby.minterfaces.MInterface_Generic;;

public abstract class Strategy_Generic
{
	MInterface_Generic minterface;
	
	public abstract void tick();
	
	public Strategy_Generic(MInterface_Generic mint)
	{
		minterface = mint;
	}
}
