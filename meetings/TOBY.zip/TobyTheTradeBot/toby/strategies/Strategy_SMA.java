package toby.strategies;


import toby.Settings;
import toby.minterfaces.MInterface_Generic;
import toby.indicators.Indicator;
import toby.indicators.SMA;

public class Strategy_SMA extends Strategy_Generic
{
	/* 3 - 24 - 786
	 * 3 - 23 - 949.8
	 * 3 - 22.5  - 1109.3
	 * 3 - 22.25 - 988.4
	 * 3 - 22.1  - 1181.3 <- winner
	 * 3 - 22 - 1160
	 * 3 - 21 - 643
	 * 3 - 20 - 520
	 * 3 - 10 - 71
	 *
	 * 2 - 22 - 387
	 * 3 - 22 - 1160
	 * 4 - 22 - 928
	 * */
	SMA shortSMA = new SMA((60*60*60*3)/Settings.tick_length);
	SMA longSMA = new SMA((int)(60*60*60*24*22.1)/Settings.tick_length);

	public Strategy_SMA(MInterface_Generic mint)
	{
		super(mint);
		Indicator.track(shortSMA);
		Indicator.track(longSMA);
		System.out.println("[Strategy-SMA]: Ready to Rumble, Boss.");
	}

	@Override
	public void tick()
	{
		MInterface_Generic m = this.minterface;
		Indicator.updateAllMinions(m.getLastPrice());

		double ssma = shortSMA.getValue();
		double lsma = longSMA.getValue();
		System.out.println("[Stragtegy-SMA]: LastPrice: "+m.getLastPrice()+", ShortSMA: "+ssma+", LongSMA: "+lsma+", Advice: "+(ssma>lsma ? "Buy!" : (ssma==lsma ? "SMAs are Equal, Wait." : "Sell!")));
		if(ssma>lsma)
		{
			//Buy!
			if(m.getBalanceUSD()>0.01)
			{
				m.cancelAllOrders();//Trailing Buy
				m.buyLimit((m.getBalanceUSD())/m.getAsk(), m.getAsk()-0.005);
			}
		}
		else if(ssma==lsma)
		{
			//Do nothing!
		}
		else
		{
			//Sell!
			if(m.getBalanceBTC()*m.getLastPrice()>0.01)
			{
				m.cancelAllOrders();//Trailing Sell
				m.sellLimit(m.getBalanceBTC(),m.getBid()+0.005);
			}
		}
	}
}
