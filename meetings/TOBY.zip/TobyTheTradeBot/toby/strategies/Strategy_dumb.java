package toby.strategies;

import toby.minterfaces.MInterface_Generic;

public class Strategy_dumb extends Strategy_Generic
{
	public Strategy_dumb(MInterface_Generic mint)
	{
		super(mint);
	}
	
	@Override
	public void tick()
	{
		MInterface_Generic m=this.minterface;
		//Do we have enough USD to buy somethin?
		if(m.getBalanceUSD()>1){
			//Spend half of it
			m.cancelAllOrders();
			m.buyMarket(m.getBalanceUSD()/2/m.getLastPrice());//c/P=C
		}
	}
	
}
