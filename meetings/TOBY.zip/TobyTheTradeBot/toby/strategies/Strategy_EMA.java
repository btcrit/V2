package toby.strategies;

import toby.Settings;
import toby.indicators.EMA;
import toby.indicators.Indicator;
import toby.minterfaces.MInterface_Generic;

public class Strategy_EMA extends Strategy_Generic
{
	//497.95 performance percentage with these parameters.
	private EMA shortEMA = new EMA(1d/((3*60*60)/Settings.tick_length));
	private EMA longEMA = new EMA(1d/((7.5*60*60)/Settings.tick_length));
	
	public Strategy_EMA(MInterface_Generic mint)
	{
		super(mint);
		Indicator.track(shortEMA);
		Indicator.track(longEMA);
	}
	
	@Override
	public void tick()
	{
		MInterface_Generic m = this.minterface;
		Indicator.updateAllMinions(m.getLastPrice());
		double sema = shortEMA.getValue();
		double lema = longEMA.getValue();
		if(sema>lema)
		{
			//Buy!
			if(m.getBalanceUSD()>0.01)
			{
				m.cancelAllOrders();//Trailing Buy
				m.buyLimit((m.getBalanceUSD())/m.getAsk(), m.getAsk()-0.005);
			}
		}
		else if(sema==lema)
		{
			//Do nothing!
		}
		else
		{
			//Sell!
			if(m.getBalanceBTC()*m.getLastPrice()>0.01)
			{
				m.cancelAllOrders();//Trailing Sell
				m.sellLimit(m.getBalanceBTC(),m.getBid()+0.005);
			}
		}
	}
}
