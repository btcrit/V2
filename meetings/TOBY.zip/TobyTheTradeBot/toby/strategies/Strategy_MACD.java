package toby.strategies;

import toby.Settings;
import toby.indicators.MACD;
import toby.indicators.Indicator;
import toby.minterfaces.MInterface_Generic;

public class Strategy_MACD extends Strategy_Generic
{
	MACD macd;
	
	@Override
	public void tick()//TODO make a util class for calculating SMAs and EMAs and MACDs 
	{
		MInterface_Generic m = this.minterface;
		Indicator.updateAllMinions(m.getLastPrice());
		macd.update(0);
		double v = macd.getValue();
		if(v>0)
		{
			//Buy!
			if(m.getBalanceUSD()>0.01)
			{
				m.cancelAllOrders();//Trailing Buy
				m.buyLimit((m.getBalanceUSD())/m.getAsk(), m.getAsk()-0.005);
			}
		}
		else if(v==0)
		{
			//Sell (By default, this seems to be safest.)
			if(m.getBalanceBTC()*m.getLastPrice()>0.01)
			{
				m.cancelAllOrders();//Trailing Sell
				m.sellLimit(m.getBalanceBTC(),m.getBid()+0.005);
			}
		}
		else
		{
			//Sell!
			if(m.getBalanceBTC()*m.getLastPrice()>0.01)
			{
				m.cancelAllOrders();//Trailing Sell
				m.sellLimit(m.getBalanceBTC(),m.getBid()+0.005);
			}
		}
	}
	
	public Strategy_MACD(MInterface_Generic mint)
	{
		super(mint);
		/*
		 * 3.0 - 7.5 - 7.5 - 52
		 * 3.0 - 7.5 - 8.0 - 80.77
		 * 3.0 - 7.5 - 9.0 - 67.138
		 * 3.0 - 7.5 - 10. - 70.7
		 * 3.0 - 7.5 - 11. - 78.93
		 * 3.0 - 7.5 - 12. - 101.5
		 * 3.0 - 7.5 - 14. - 120.6
		 * 3.0 - 7.5 - 18. - 168.9
		 * 3.0 - 7.5 - 26. - 426.8
		 * 3.0 - 7.5 - 34. - 695.4
		 * 3.0 - 7.5 - 35. - 692.0
		 * 3.0 - 7.5 - 36. - 746.1
		 * 3.0 - 7.5 - 36.25-743.6
		 * 3.0 - 7.5 - 36.5- 774.2 <- winner
		 * 3.0 - 7.5 - 37. - 689.8
		 * 3.0 - 7.5 - 38. - 685.2
		 * 3.0 - 7.5 - 42. - 622.0
		 * 3.0 - 7.5 - 78. - 323.6
		 * 
		 * 3.0 - 22.1- 36.5- 470.9
		 * */
		macd = new MACD(
				1/((double)(3*60*60)/Settings.tick_length),//short
				1/((double)(7.5*60*60)/Settings.tick_length),//Long
				1/((double)(36*60*60)/Settings.tick_length));//Signal
		//Do not track the MACD, as we must guarantee that it is updated after its components.
	}
}
