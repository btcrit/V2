package toby.minterfaces;

public abstract class MAPI_Generic
{
	
	public MAPI_Generic()
	{
		// TODO Auto-generated constructor stub
	}
	
}
