package toby.minterfaces;

public class MAPI_Simulated
{
	
	public MAPI_Simulated()
	{
		// TODO Auto-generated constructor stub
	}
	
}
