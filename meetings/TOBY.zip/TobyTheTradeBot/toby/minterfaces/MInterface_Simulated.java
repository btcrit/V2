package toby.minterfaces;
import java.util.ArrayList;
import java.util.List;

import toby.Settings;
import toby.SimulatedMarket.Currency;
import toby.SimulatedMarket.SimulatedMarket;

public class MInterface_Simulated extends MInterface_Generic
{
	
	boolean debug = false;
	
	SimulatedMarket sm;
	
	ArrayList<Double> history = new ArrayList<Double>();
	
	
	public MInterface_Simulated()
	{
		System.out.println("[MarketInterface-Simulated]: Creating Simulated Market...");
		sm = new SimulatedMarket();
		System.out.println("[MarketInterface-Simulated]: Simulated Market Created! Simulated Market Interface Created!");
	}

	@Override
	public void pretick()
	{
		System.out.print("[MarketInterface-Simulated]: Simulating Market...");
		sm.runFor(Settings.tick_length);
		history.add(sm.getLastPrice());
		System.out.println(" Done!");
	}

	@Override
	public void buyLimit(double volume, double price)
	{
		if(debug)System.out.println("[MarketInterface-Simulated]: Submitting BUY order for "+volume+" coins at "+price);
		sm.buy(volume, price);
	}

	@Override
	public void buyMarket(double volume)
	{
		if(debug) System.out.println("[MarketInterface-Simulated]: Submitting BUY order for "+volume+" coins at MARKET.");
		sm.buy(volume);
	}

	@Override
	public void buyStop(double volume, double stop)
	{
		System.out.println("[MarketInterface-Simulated]: Simulation does not yet support Buy Stop orders.");
	}

	@Override
	public void sellLimit(double volume, double price)
	{
		if(debug) System.out.println("[MarketInterface-Simulated]: Submitting SELL order for "+volume+" coins at "+price);
		sm.sell(volume, price);
	}

	@Override
	public void sellMarket(double volume)
	{
		System.out.println("[MarketInterface-Simulated]: Simulation does not yet support Sell limit orders.");
	}

	@Override
	public void sellStop(double volume, double stop)
	{
		System.out.println("[MarketInterface-Simulated]: Simulation does not yet support Sell Stop orders.");
	}

	@Override
	public double getBalanceUSD()
	{
		return sm.getBalance(Currency.usd);
	}

	@Override
	public double getBalanceBTC()
	{
		return sm.getBalance(Currency.btc);
	}

	@Override
	public double getLastPrice()
	{
		return sm.getLastPrice();
	}

	@Override
	public double getBid()
	{
		return getLastPrice();
	}

	@Override
	public double getAsk()
	{
		return getLastPrice();
	}

	@Override
	public double[] getLastTickPrices(int numberOfTicks)
	{
		// TODO This one needs work
		// Remember: Time between prices is equal to Settings.tick_time;
		List<Double> smallList = history.subList(Math.max(0, history.size()-numberOfTicks), history.size()-1);
		// SPOOKY SPOOKY SPOOKY SPOOKY SPOOKY SPOOKY. What is this and how does it work?
		// That arrow means Lambda -> What? What is lambda and how does it work? TODO.
		return smallList.stream().mapToDouble(d -> d).toArray();
	}

	@Override
	public void cancelAllOrders()
	{
		System.out.println("[MarketInterface-Simulated]: Submitting request to Cancel All Orders.");
		sm.cancelAllOrders();
	}
	
}
