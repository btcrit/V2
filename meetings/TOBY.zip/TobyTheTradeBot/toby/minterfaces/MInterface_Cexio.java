package toby.minterfaces;

public class MInterface_Cexio extends MInterface_Generic
{
	
	public MInterface_Cexio(){}
	
	@Override
	public void pretick()
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	public void buyLimit(double volume, double price){}

	@Override
	public void buyMarket(double volume){}
	@Override
	public void buyStop(double volume, double stop){}

	@Override
	public void sellLimit(double volume, double price){}

	@Override
	public void sellMarket(double volume){}

	@Override
	public void sellStop(double volume, double stop){}

	@Override
	public double getBalanceUSD()
	{
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double getBalanceBTC()
	{
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double getLastPrice()
	{
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double getBid()
	{
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double getAsk()
	{
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double[] getLastTickPrices(int numberOfTicks)
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void cancelAllOrders()
	{
		// TODO Auto-generated method stub
		
	}
	
}
