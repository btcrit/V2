package toby.minterfaces;

public abstract class MInterface_Generic
{
	//Store last price
	//Store last X prices
	//Store last balances
	public abstract void cancelAllOrders();
	public abstract void buyLimit(double volume, double price);
	public abstract void buyMarket(double volume);
	public abstract void buyStop(double volume, double stop);
	public abstract void sellLimit(double volume, double price);
	public abstract void sellMarket(double volume);
	public abstract void sellStop(double volume, double stop);
	public abstract double getBalanceUSD();
	public abstract double getBalanceBTC();
	public abstract double getLastPrice();
	public abstract double getBid();
	public abstract double getAsk();
	//Do we want something to calc SMAs and EMAs and MACDs and RSIs for us? Yeah. But, we'll do that later.
	//Get the n last closing prices
	public abstract double[] getLastTickPrices(int numberOfTicks);
	public abstract void pretick();	
	public MInterface_Generic(){}
}
