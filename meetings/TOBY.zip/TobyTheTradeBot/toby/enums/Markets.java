package toby.enums;

public enum Markets
{
	simulated,
	hybrid,
	cexio
}
