package toby.indicators;

public class EMA extends Indicator
{
	private Double oldEMA;
	private double currentEMA;
	private double decay;// 0 to 1, 1 discards old values immediately. 
	
	public EMA(double decay)
	{
		this.decay = decay;
		System.out.println("EMA with decay of: "+decay);
	}
	
	@Override
	public void update(double price)
	{
		if(oldEMA==null)
		{
			oldEMA = price;
			return;
		}
		oldEMA = currentEMA;
		currentEMA = oldEMA + decay*(price-oldEMA);
	}
	
	public double getValue(){
		return currentEMA;
	}
}
