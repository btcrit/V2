package toby.indicators;

import java.util.ArrayList;
import java.util.List;

public abstract class Indicator
{
	
	private static ArrayList<Indicator> minions = new ArrayList<Indicator>();
	
	//Update all minions
	public static void updateAllMinions(double d)
	{
		for(Indicator i : minions)
			i.update(d);
	}
	//Add minions
	public static void track(Indicator i)
	{
		minions.add(i);
	}
	public Indicator(){}
	public abstract void update(double price);
	//Initialize an Indicator with Data
	public void initialize(ArrayList<Double> data){
		for(double d : data)
			this.update(d);
	}
	public void initialize(double[] data){
		for(double d : data)
			this.update(d);
	}
	//Select the last N data from Dataset
	public static double[] selectData(int n, ArrayList<Double> data)
	{
		//Get only the last bits of data
		List<Double> smallList = data.subList(Math.max(0, data.size()-n), data.size()-1);
		//Convert to double array for processing and return. TODO - put this conversion in a different function.
		return smallList.stream().mapToDouble(d -> d).toArray();
	}
}
