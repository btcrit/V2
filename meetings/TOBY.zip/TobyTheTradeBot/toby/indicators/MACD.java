package toby.indicators;

public class MACD extends Indicator
{
	EMA shortEMA;
	EMA longEMA;
	//Macd - diff between short and long EMA
	EMA macdEMA;//Signal Line
	//Final value = macd - signal
	public MACD(double decay1, double decay2, double decay3)
	{
		shortEMA = new EMA(decay1);//Largest decay, most sensitive
		Indicator.track(shortEMA);//Will now auto-update with market
		longEMA = new EMA(decay2);
		Indicator.track(longEMA);//Also auto updates
		macdEMA = new EMA(decay3);//Does not auto update
	}
	
	@Override
	public void update(double price)
	{
		// Short and Long EMAs are updated when strategy calls Indicator.updateAll();
		// We just need to update the macdEMA
		macdEMA.update(shortEMA.getValue()-longEMA.getValue());
	}
	
	public double getValue()
	{
		return (shortEMA.getValue()-longEMA.getValue())-macdEMA.getValue();
	}//Damn son this is a complex indicator.
}
