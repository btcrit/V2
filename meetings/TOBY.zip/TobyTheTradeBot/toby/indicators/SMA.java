package toby.indicators;

import java.util.ArrayList;

public class SMA extends Indicator
{
	private int period;
	private ArrayList<Double> data = new ArrayList<Double>();
	
	public SMA(int period)
	{
		this.period=period;
	}
	
	@Override
	public void update(double price)
	{
		data.add(price);
		while(data.size()>period)
			data.remove(0);
	}

	public double getValue()
	{
		//Add it all up
		double total =0;
		for(double d : data)
			total+=d;
		return total/data.size();
	}
}
