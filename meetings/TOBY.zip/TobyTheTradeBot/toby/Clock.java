package toby;

public class Clock
{
	public void tick()
	{
		//Are we using a Real-time market? (Are we not using the simulated market?)
		if(!Settings.MARKET_SYSTEM.getName().equals("toby.minterfaces.MInterface_Simulated"))
		{
			//Wait for time
			System.out.println("[Clock]: Waiting for next Scheduled Analysis...");
			try
			{
				Thread.sleep(Settings.tick_length*1000);
			}
			catch (InterruptedException e)
			{
				//TODO Why were we interrupted? Message from the mothership? Handle that.
				System.out.println("[Clock]: Clock was interupted during sleep.");
				e.printStackTrace();
			}
		}
		else
		{
			//We are using the purely simulated market - don't sleep.
			System.out.println("[Clock]: Running Simulated Market, No need to wait.");
			return;
		}
	}
	public Clock(){}
}
