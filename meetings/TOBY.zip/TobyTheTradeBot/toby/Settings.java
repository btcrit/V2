package toby;
import toby.minterfaces.*;
import toby.strategies.*;

// Static Settings Stuff
public class Settings
{
	//How often shall we calculate a movement? (Seconds)
	public static final int tick_length = 60*60;//1 minute

	//Which Strategy Shall we use To Trade?
	public static final Class<? extends Strategy_Generic> strategy = Strategy_SMA.class;

	//Which Market Shall we Trade In? TODO Get rid of this
	public static final Class<? extends MInterface_Generic> MARKET_SYSTEM = MInterface_Simulated.class;

	//Variables for running simulations
	public static final class simulationSettings{
		public static final double startingBTC = 0;
		public static final double startingUSD = 100;
		/*Start Times
		 * 		2017: 1483228800
		 * December 2016: 1480550400
		 * November 2016: 1477958400
		 *  October 2016: 1475280000
		 * 18th Birthday: 1474588800
		 * */
		public static final long startTime = 1474588800;
		//public static final String dataFile = "C:\\Users\\e.witherington\\workspace\\Trade_Bot\\src\\volatilityResistanceBot\\bitfinexUSD.csv";
		public static final String dataFile = "/home/ethan/projects/btcrit/TobyTheTradeBot/BacktestingData/bitstampUSD.csv";
	}//*/

	//Prevent Instantiation
	private Settings(){};

	public static void importSettings(){
		System.out.println("----- Importing Settings -----");
	}
}
