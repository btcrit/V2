package toby.SimulatedMarket;

import java.util.ArrayList;
import java.util.HashMap;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import toby.Settings;

// Hard mode! Because we cannot read logs from real markets, SimulatedMarket will always fail silently!
// That means no exceptions, no output, nothing. If you do something wrong, you loose everything.

public class SimulatedMarket{
	//Current simulation time
	private long elapsedTime = 0L;
	//keep track of orders
	private ArrayList<Order> orders = new ArrayList<Order>();
	//Keep track of account balances
	private HashMap<Currency, Double> balance = new HashMap<Currency, Double>();
	//The price of the last trade
	private double lastPrice;
	private double firstPrice;
	//...
	private static final String COMMA_DELIMITER = ",";
	//For reading trade data from file
	BufferedReader br = null;
	
	//Process orders given the last price/volume
	private void handle(double price, double volume){
		//For every order
		for(int i=0;i<orders.size();i++){
			Order order = orders.get(i);
			//handle sell orders
			if(order.type==OrderTypes.sell && price > order.price){
				//How much volume goes through
				double volumeact = Math.min(order.volume, volume);
				//Make sure balances are sufficient
				if(volumeact > balance.get(Currency.btc)){
					fail();
				}
				//Increase USD balance
				balance.put(Currency.usd, balance.get(Currency.usd)+order.price*volumeact);
				//Decrease BTC balance
				balance.put(Currency.btc, balance.get(Currency.btc)-volumeact);
				//Decrease order volume
				order.volume -= volumeact;
				//If it's done, kill it.
				if(order.volume <= 0){
					orders.remove(order);
				}
			}
			//handle buy orders
			if(order.type==OrderTypes.buy && price < order.price){
				//How much volume goes through
				double volumeact = Math.min(order.volume, volume);
				if(volumeact > balance.get(Currency.usd)/order.price){
					fail();
				}
				//System.out.println("BUY Goes through: "+volumeact+"BTC at $"+Math.min(order.price, price)+" per coin. "+"Order volume: "+order.volume+", order price: "+order.price);
				//Decrease USD balance
				balance.put(Currency.usd, balance.get(Currency.usd)-order.price*volumeact);
				//Increase BTC balance
				balance.put(Currency.btc, balance.get(Currency.btc)+volumeact);
				//decrease the order volume
				order.volume -= volumeact;
				//If it's done, kill it.
				if(order.volume <= 0){
					orders.remove(order);
				}
			}
		}
	}
	
	public void runFor(double seconds){
		runUntil((long)seconds + elapsedTime);
	}
	
	public void runUntil(long time){		
		String line = "";
        try {
			while ((line = br.readLine()) != null) 
			{
			    String[] items = line.split(COMMA_DELIMITER);
			    if(items.length > 0 )
			    {
			    	long timestamp = Long.parseLong(items[0]);
			        double price = Double.parseDouble(items[1]);
			        double volume = Double.parseDouble(items[2]);
			        lastPrice = price;
			        elapsedTime = timestamp;
			        handle(price, volume);
			        if(timestamp >= time)
			        	return;
			    }else{
			        System.out.println("Got line with No Data");
			    }
			}
			close();
		} catch (NumberFormatException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	private void startAt(long time){
	String line = "";
	try {
		while ((line = br.readLine()) != null) 
		{
		    String[] items = line.split(COMMA_DELIMITER);
		    if(items.length > 0 )
		    {
		    	long timestamp = Long.parseLong(items[0]);
		        double price = Double.parseDouble(items[1]);
		        firstPrice = lastPrice = price;
		        elapsedTime = timestamp;
		        if(timestamp >= time)
		        	return;
		    }else{
		        System.out.println("Got line with No Data");
		    }
		}
		close();
	} catch (NumberFormatException e) {
		e.printStackTrace();
	} catch (IOException e) {
		e.printStackTrace();
	}
	}
	private void openData(){
		try {
			br = new BufferedReader(new FileReader(Settings.simulationSettings.dataFile));
			String line = "";
	        try {
				line = br.readLine(); 
			    String[] items = line.split(COMMA_DELIMITER);
			    if(items.length > 0 )
			    {
			    	long timestamp = Long.parseLong(items[0]);
			        double price = Double.parseDouble(items[1]);
			        firstPrice = lastPrice = price;
			        elapsedTime = timestamp;
			    }else{
			        System.out.println("[MarketSim]: Gah! There is no Data on the first line! Correct your sample data and try again. Exiting...");
			        System.exit(1);
			    }
			} catch (NumberFormatException e) {
				System.out.println("[MarketSim]: NumberFormatException! Check your sample data and try again. Printing Error and exiting...");
				e.printStackTrace();
				System.exit(1);
			} catch (IOException e) {
				System.out.println("[MarketSim]: Error reading Sample Data. Check the file and try again. Printing Error and exiting...");
				e.printStackTrace();
				System.exit(1);
			}
		} catch (FileNotFoundException e) {
			System.out.println("[MarketSim]: Specified Sample Data does not Exist! Check your file and settings and try again. Printing Error and exiting...");
			e.printStackTrace();
			System.exit(1);
		}
		System.out.println("[MarketSim]: Sample Market Data acquired Succesfully!");
	}
	
	private void close(){
		try
		  {
		      br.close();
		  }
		  catch(IOException ie)
		  {
		      System.out.println("Error occured while closing the BufferedReader");
		      ie.printStackTrace();
		  }
		double init = Settings.simulationSettings.startingBTC*firstPrice+Settings.simulationSettings.startingUSD;
		double finalVal = (getBalance(Currency.btc)*lastPrice+getBalance(Currency.usd));
		double bhfv = (Settings.simulationSettings.startingBTC+Settings.simulationSettings.startingUSD/firstPrice)*lastPrice;
		System.out.println("Out of simulation Data!"+"\n"
				+ "                 Initial Value: " + init + "\n"
				+ "                   Final Value: " + toTwo(finalVal) + "\n"
				+ "                   Profit/loss: "+ toTwo(finalVal - init) + "\n"
				+ "               Percent Returns: " +toTwo(((finalVal-init)/init)*100)+"%\n"
				+ "            Buy and Hold final: " + toTwo(bhfv) + "\n"
				+ "Performance Against the Market: " + toTwo((finalVal-bhfv)/bhfv*100)+"%");
		System.exit(0);
	}
	private double toTwo(double d){
		return (((int)(d*100))/100);
	}
	public SimulatedMarket() {
		System.out.println("[MarketSim]:");
		System.out.println("[MarketSim]: ------------------------------------------------------------------------------------------------------");
		System.out.println("[MarketSim]: -                                                                                                    -");
		System.out.println("[MarketSim]: - Real Markets will Not give feedback, so I won't either. Rely on the Market Interfaces for Logging. -");
		System.out.println("[MarketSim]: -                                                                                                    -");
		System.out.println("[MarketSim]: ------------------------------------------------------------------------------------------------------");
		System.out.println("[MarketSim]:");
		System.out.print("[MarketSim]: Pulling Settings... ");
		balance.put(Currency.btc, Settings.simulationSettings.startingBTC);
		balance.put(Currency.usd, Settings.simulationSettings.startingUSD);
		System.out.println("Done! Acquiring Sample Market Data...");
		openData();
		System.out.println("[MarketSim]: Simulating Market up to start time...");
		startAt(Settings.simulationSettings.startTime);
		System.out.println("[MarketSim]: Simulated Market is Built and Ready to Run!");
	}
	
	public void buy(double volume, double price){
		if(volume <= 0) fail();
		orders.add(new Order(OrderTypes.buy, volume, price));
	}

	public void sell(double volume, double price){
		if(volume <= 0) fail();
		orders.add(new Order(OrderTypes.sell, volume, price));
	}

	public void cancelAllOrders() {
		orders.clear();
	}

	public double getBalance(Currency c) {
		return balance.get(c);
	}
	
	public double getLastPrice() {
		return lastPrice;
	}

	private void fail(){
		System.out.println("You loose!");
		System.exit(5);//5 because why not
	}
	
	public void buy(double volume){
		buy(volume, lastPrice);
	}
}
