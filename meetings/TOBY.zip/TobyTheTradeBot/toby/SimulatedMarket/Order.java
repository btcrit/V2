package toby.SimulatedMarket;

public class Order {
	public OrderTypes type;
	public double volume;
	public double price;
	public Order(OrderTypes type, double volume, double price) {
		this.type = type;
		this.volume = volume;
		this.price = price;
	}
}
