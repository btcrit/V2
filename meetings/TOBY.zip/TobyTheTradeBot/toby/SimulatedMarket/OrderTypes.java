package toby.SimulatedMarket;

public enum OrderTypes {
	buy,
	sell
}
