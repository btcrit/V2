package toby.SimulatedMarket;

public enum Currency {
	btc,
	usd
}
