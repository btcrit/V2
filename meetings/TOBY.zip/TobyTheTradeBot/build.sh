javac @./toby/classes
