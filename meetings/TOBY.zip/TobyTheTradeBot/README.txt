# Adjusting Settings

Settings are stored in toby/Settings.java.
You'll need to adjust the path to the backtesting data.

# Compiling

toby/classes contains a list of toby's source code files. You'll need to
adjust this file.

The command to compile everything is stored in build.sh

# Running

The command to run toby is in run.sh. I recommend saving the output to a file.
